function calculate() {
    const bodyweight = parseFloat(document.getElementById('bodyweight').value);
    const extraweight = parseFloat(document.getElementById('extraweight').value);
    const reps = parseInt(document.getElementById('reps').value);

    // Bereken 1RM met de Epley-formule
    const oneRM = (extraweight * reps * 0.0333) + extraweight + bodyweight;

    // Percentages en geschatte herhalingen
    const percentages = [100, 95, 90, 85, 80, 75, 70, 65, 60];
    const estimatedReps = ["1", "2-3", "3-4", "4-5", "6-7", "8-9", "10-12", "12-15", "15-20"];

    // Vul de tabel
    const table = document.getElementById('result-table');
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = ""; // Reset de tabel

    percentages.forEach((percentage, index) => {
        const totalWeight = (oneRM * (percentage / 100)).toFixed(2);
        const addedWeight = (totalWeight - bodyweight).toFixed(2);

        const row = `<tr>
            <td>${percentage}%</td>
            <td>${totalWeight}</td>
            <td>${addedWeight}</td>
            <td>${estimatedReps[index]}</td>
        </tr>`;
        tbody.innerHTML += row;
    });

    table.style.display = "table"; // Toon de tabel
}

// Register service worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
        .then(() => console.log('Service Worker Registered'));
}
